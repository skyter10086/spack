# Copyright 2013-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the top-level COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

# ----------------------------------------------------------------------------
# If you submit this package back to Spack as a pull request,
# please first remove this boilerplate and all FIXME comments.
#
# This is a template package file for Spack.  We've put "FIXME"
# next to all the things you'll want to change. Once you've handled
# them, you can save this file and test your package like this:
#
#     spack install corge
#
# You can edit this file again by typing:
#
#     spack edit corge
#
# See the Spack documentation for more information on packaging.
# ----------------------------------------------------------------------------

from spack import *


class Corge(CMakePackage):
    """A toy package to test dependencies"""

    homepage = "https://www.example.com"
    url      = "https://github.com/amundson/corge/archive/v3.0.0.tar.gz"

    version(
        '3.0.0', sha256='5058861c3b887511387c725971984cec665a8307d660158915a04d7786fed6bc')
    version(
        '2.0.0', sha256='227c86e986ad70585cd105d5f7e80a88b98906647b9865e4919d896312102afe')
    version(
        '1.0.4', sha256='ed31116a203b39880f4b3dd81d1690978f42452aefda5266c09dcc793029116f')
    version(
        '1.0.3', sha256='3a8fd976925f1908bef8eb94996d176dd911803f72b8634ba14835b55e704df6')
    version(
        '1.0.2', sha256='851dd3141b4237f7413deda12e6ff74901a99a4d2c79caaca87964ff818e2d66')
    version(
        '1.0.1', sha256='de5f3ecaa6043f530a0231e9f0ebbb08df47b23dc80f0bc203e6553c745e8ff8')

    depends_on('quux')

    def cmake_args(self):
        args = []
        return args
