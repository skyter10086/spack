# Copyright 2013-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the top-level COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

# ----------------------------------------------------------------------------
# If you submit this package back to Spack as a pull request,
# please first remove this boilerplate and all FIXME comments.
#
# This is a template package file for Spack.  We've put "FIXME"
# next to all the things you'll want to change. Once you've handled
# them, you can save this file and test your package like this:
#
#     spack install quux
#
# You can edit this file again by typing:
#
#     spack edit quux
#
# See the Spack documentation for more information on packaging.
# ----------------------------------------------------------------------------

from spack import *


class Quux(CMakePackage):
    """Toy package for testing dependencies"""

    homepage = "https://www.example.com"
    url      = "https://github.com/amundson/quux/archive/v3.0.0.tar.gz"

    version('3.0.0', sha256='b91bc96fb746495786bddac2c527039177499f2f76d3fa9dcf0b393859e68484')
    version('2.0.0', sha256='1730fd122ae52cc3ccb287d1a9019e9c95bd714354c6ea6a7871eb61d16170c4')
    version('1.0.3', sha256='7f1a6893cae2b60fc1371b6873bab3e0ddbaf396c68ca6e5ce43652415162457')
    version('1.0.2', sha256='e4b81d7beb0c4761ff8f28f697d8514299ab12626ef50f7bb66fc8722f1f0ee5')
    version('1.0.1', sha256='a07b9410a48b5637a097a4056d3fad997d4ce878c906bba34f7ad9c0aaf4ff49')

    depends_on('garply')

    def cmake_args(self):
        args = []
        return args
