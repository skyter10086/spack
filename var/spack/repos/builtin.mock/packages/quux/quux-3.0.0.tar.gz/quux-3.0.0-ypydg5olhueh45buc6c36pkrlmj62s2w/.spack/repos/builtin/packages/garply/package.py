# Copyright 2013-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the top-level COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

# ----------------------------------------------------------------------------
# If you submit this package back to Spack as a pull request,
# please first remove this boilerplate and all FIXME comments.
#
# This is a template package file for Spack.  We've put "FIXME"
# next to all the things you'll want to change. Once you've handled
# them, you can save this file and test your package like this:
#
#     spack install garply
#
# You can edit this file again by typing:
#
#     spack edit garply
#
# See the Spack documentation for more information on packaging.
# ----------------------------------------------------------------------------

from spack import *


class Garply(CMakePackage):
    """Toy package for testing dependencies"""

    homepage = "https://www.example.com"
    url      = "https://github.com/amundson/garply/archive/v3.0.0.tar.gz"

    version(
        '3.0.0', sha256='534ac8ba7a6fed7e8bbb543bd43ca04999e65337445a531bd296939f5ac2f33d')
    version(
        '2.0.0', sha256='4215a74f7d08861c12b5b6db9c346a135cc5330ab519fe51232acaba0cc22d07')
    version(
        '1.0.1', sha256='ac16f3dbc6ece9e134804e6daccfc373c7b8d21c0c4500bdda8c9cba2c1509b4')

    def cmake_args(self):
        args = []
        return args
